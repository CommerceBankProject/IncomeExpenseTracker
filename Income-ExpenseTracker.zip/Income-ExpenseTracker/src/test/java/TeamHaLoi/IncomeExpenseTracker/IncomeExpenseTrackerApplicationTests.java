package TeamHaLoi.IncomeExpenseTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncomeExpenseTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
